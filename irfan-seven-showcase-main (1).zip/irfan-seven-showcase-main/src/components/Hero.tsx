import { Button } from '@/components/ui/button';
import { Github, Linkedin, Twitter, Mail, Download, ArrowDown } from 'lucide-react';
import profileImage from '@/assets/profile-image.jpg';

const Hero = () => {
  const socialLinks = [
    { icon: Github, href: 'https://github.com', label: 'GitHub' },
    { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
    { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
    { icon: Mail, href: 'mailto:contact@example.com', label: 'Email' },
  ];

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <p className="text-muted-foreground text-lg">Hello, I'm</p>
              <h1 className="text-5xl md:text-7xl font-bold">
                Irfan <br />
                <span className="text-gradient">Ahamed</span>
              </h1>
              <h2 className="text-xl md:text-2xl text-muted-foreground">
                I'm a <span className="text-primary font-semibold">Software Developer</span>
              </h2>
            </div>

            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Full Stack Developer with 2 years of industry experience specializing in building 
              exceptional digital experiences with a passion for{' '}
              <span className="text-primary font-semibold">AI & IoT</span> technologies. 
              I create innovative solutions that bridge the gap between creativity and functionality.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button variant="hero" size="lg" className="relative">
                Get In Touch
              </Button>
              <Button variant="glass" size="lg">
                View Work
              </Button>
              <Button variant="outline" size="lg" className="gap-2">
                <Download className="w-4 h-4" />
                Resume
              </Button>
            </div>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-muted-foreground">Available for work</span>
              </div>
              
              <div className="flex gap-4">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    className="p-2 rounded-lg hover:bg-secondary transition-colors star-trail relative group"
                    aria-label={social.label}
                  >
                    <social.icon className="w-5 h-5 group-hover:text-primary transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Right Content - Profile Image */}
          <div className="relative">
            <div className="relative w-80 h-80 mx-auto">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full blur-3xl animate-pulse"></div>
              <img
                src={profileImage}
                alt="Irfan Ahamed - Professional Photo"
                className="relative z-10 w-full h-full object-cover rounded-full border-4 border-primary/20 animate-float"
              />
            </div>

            {/* Floating Elements */}
            <div className="absolute top-10 right-10 glass-effect p-4 rounded-lg animate-float" style={{ animationDelay: '1s' }}>
              <code className="text-primary text-sm">const developer = 'passionate'</code>
            </div>

            <div className="absolute bottom-10 left-10 glass-effect p-3 rounded-lg animate-float" style={{ animationDelay: '2s' }}>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">2</div>
                <div className="text-xs text-muted-foreground">Years Experience</div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-6 h-6 text-primary" />
        </div>
      </div>
    </section>
  );
};

export default Hero;