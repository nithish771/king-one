import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  const highlights = [
    { title: 'Experience', value: '2+ Years Industry' },
    { title: 'Specialization', value: 'Full Stack + AI/IoT' },
    { title: 'Location', value: 'Coimbatore, India' },
    { title: 'Languages', value: 'English, Hindi, Tamil' },
    { title: 'Status', value: 'Open to Opportunities' },
  ];

  return (
    <section id="about" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold mb-4">About Me</h2>
              <div className="space-y-2 mb-6">
                <p className="text-xl text-primary font-semibold">Full Stack Developer | AI & IoT Specialist</p>
                <p className="text-lg text-muted-foreground">Cybersecurity Enthusiast | Tech Innovation Driver</p>
              </div>
            </div>

            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Passionate Full Stack Developer with <span className="text-primary font-semibold">2 years of industry experience</span> specializing in modern web technologies, artificial intelligence integration, and IoT ecosystem development. My expertise spans across frontend frameworks, backend architectures, cloud platforms, and emerging technologies.
              </p>
              <p>
                I excel in <span className="text-primary font-semibold">JavaScript ecosystem technologies</span>, including React.js, Node.js, and TypeScript, while maintaining proficiency in Python for AI/ML implementations. My approach emphasizes clean architecture, scalable solutions, and performance optimization.
              </p>
              <p>
                Currently exploring <span className="text-primary font-semibold">edge computing</span>, serverless architectures, and advanced cybersecurity practices. I believe in continuous learning, open-source contribution, and building technology solutions that make a meaningful impact.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {highlights.map((item, index) => (
              <Card key={item.title} className="glass-effect border-primary/20 hover:border-primary/40 transition-all duration-300 star-hover floating-stars">
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">{item.title}</span>
                    <span className="font-semibold text-primary relative">
                      {item.value}
                      <span className="absolute -top-1 -right-3 text-xs opacity-0 hover:opacity-100 transition-opacity">⭐</span>
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;