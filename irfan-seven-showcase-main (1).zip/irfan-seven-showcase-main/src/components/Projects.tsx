import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github, Eye } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'AI-Powered Task Manager',
      description: 'Intelligent task management application with AI-driven priority suggestions and automated scheduling using machine learning algorithms.',
      image: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=500&h=300&fit=crop',
      technologies: ['React', 'Node.js', 'OpenAI API', 'MongoDB', 'TensorFlow'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'AI Integration'
    },
    {
      title: 'IoT Smart Home Dashboard',
      description: 'Comprehensive IoT dashboard for smart home automation with real-time sensor monitoring and device control capabilities.',
      image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500&h=300&fit=crop',
      technologies: ['React', 'Node.js', 'MQTT', 'Arduino', 'WebSocket'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'IoT Solutions'
    },
    {
      title: 'E-commerce Platform',
      description: 'Full-stack e-commerce solution with advanced features like real-time inventory, payment integration, and analytics dashboard.',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&h=300&fit=crop',
      technologies: ['Next.js', 'Stripe', 'PostgreSQL', 'Prisma', 'Tailwind CSS'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'Web Development'
    },
    {
      title: 'Cybersecurity Audit Tool',
      description: 'Automated security assessment tool that scans web applications for vulnerabilities and generates comprehensive security reports.',
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=500&h=300&fit=crop',
      technologies: ['Python', 'Flask', 'SQLite', 'Nmap', 'BeautifulSoup'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'Cybersecurity'
    },
    {
      title: 'Real-time Chat Application',
      description: 'Modern chat application with end-to-end encryption, file sharing, and real-time notifications using WebSocket technology.',
      image: 'https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=500&h=300&fit=crop',
      technologies: ['React', 'Socket.io', 'Express', 'JWT', 'MongoDB'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'Web Development'
    },
    {
      title: 'Machine Learning Portfolio',
      description: 'Collection of ML projects including predictive analytics, image recognition, and natural language processing implementations.',
      image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=500&h=300&fit=crop',
      technologies: ['Python', 'Scikit-learn', 'TensorFlow', 'Pandas', 'Jupyter'],
      liveUrl: '#',
      githubUrl: '#',
      category: 'AI Integration'
    }
  ];

  return (
    <section id="projects" className="py-20 bg-secondary/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Featured Projects</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            A showcase of my recent work spanning web development, AI integration, IoT solutions, and cybersecurity implementations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card 
              key={project.title}
              className="glass-effect border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105 group star-hover sparkle-on-hover overflow-hidden"
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 bg-primary/20 text-primary text-xs rounded-full border border-primary/30 floating-stars">
                    {project.category}
                  </span>
                </div>
              </div>
              
              <CardHeader>
                <CardTitle className="text-xl relative">
                  {project.title}
                  <span className="absolute -top-1 -right-6 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">✨</span>
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button variant="ghost" size="sm" className="gap-2 flex-1">
                    <Eye className="w-4 h-4" />
                    Live Demo
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 flex-1">
                    <Github className="w-4 h-4" />
                    Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="hero" size="lg" className="gap-2">
            <ExternalLink className="w-4 h-4" />
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Projects;