const Stats = () => {
  const stats = [
    { number: '50+', label: 'Projects Completed' },
    { number: '25+', label: 'Happy Clients' },
    { number: '1500+', label: 'Cups of Coffee' },
    { number: '5+', label: 'Years Experience' },
  ];

  return (
    <section className="py-20 bg-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={stat.label}
              className="text-center group hover:scale-105 transition-transform duration-300 star-hover relative"
            >
              <div className="mb-4">
                <div className="text-4xl md:text-5xl font-bold text-gradient mb-2 relative">
                  {stat.number}
                  <span className="absolute -top-2 -right-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">✨</span>
                </div>
                <div className="text-sm md:text-base text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;