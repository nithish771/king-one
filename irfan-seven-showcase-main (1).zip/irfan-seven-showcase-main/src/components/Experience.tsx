import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, MapPin } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: 'Full Stack Developer',
      company: 'Tech Solutions Inc.',
      location: 'Remote',
      period: '2022 - Present',
      description: 'Leading development of modern web applications using React, Node.js, and cloud technologies. Implemented AI-powered features and IoT integrations for enterprise clients.',
      achievements: [
        'Developed 15+ responsive web applications',
        'Improved application performance by 40%',
        'Led a team of 3 junior developers',
        'Integrated AI/ML solutions for data analytics'
      ]
    },
    {
      title: 'Frontend Developer',
      company: 'Digital Agency Pro',
      location: 'Coimbatore, India',
      period: '2021 - 2022',
      description: 'Specialized in creating user-friendly interfaces and optimizing user experience for various client projects using modern JavaScript frameworks.',
      achievements: [
        'Delivered 20+ client projects on time',
        'Increased user engagement by 35%',
        'Implemented responsive design principles',
        'Collaborated with design teams effectively'
      ]
    },
    {
      title: 'Junior Developer',
      company: 'StartUp Hub',
      location: 'Chennai, India',
      period: '2020 - 2021',
      description: 'Started career developing web applications and learning modern development practices. Gained experience in full-stack development and project management.',
      achievements: [
        'Contributed to 10+ successful projects',
        'Learned React, Node.js, and MongoDB',
        'Implemented security best practices',
        'Participated in code reviews and testing'
      ]
    }
  ];

  return (
    <section id="experience" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Professional Journey</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            My career progression through various roles, building expertise in full-stack development, AI integration, and IoT solutions.
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card 
              key={exp.title + exp.company} 
              className="glass-effect border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-[1.02] star-hover sparkle-on-hover group"
            >
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <CardTitle className="text-xl text-gradient mb-2 relative">
                      {exp.title}
                      <span className="absolute -top-1 -right-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">⚡</span>
                    </CardTitle>
                    <div className="text-lg font-semibold text-primary">{exp.company}</div>
                  </div>
                  <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{exp.period}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{exp.location}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  {exp.description}
                </p>
                
                <div>
                  <h4 className="font-semibold mb-3 text-primary">Key Achievements:</h4>
                  <ul className="space-y-2">
                    {exp.achievements.map((achievement, achievementIndex) => (
                      <li key={achievementIndex} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0 floating-stars"></span>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;