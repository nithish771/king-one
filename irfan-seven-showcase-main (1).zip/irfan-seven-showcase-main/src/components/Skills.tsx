import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Frontend Development',
      description: 'Architecting responsive, scalable user interfaces using modern JavaScript frameworks with emphasis on performance optimization, component reusability, and state management patterns.',
      skills: ['React.js', 'Next.js', 'TypeScript', 'Redux Toolkit', 'Tailwind CSS', 'Vite']
    },
    {
      title: 'Backend Engineering',
      description: 'Developing robust server-side applications with RESTful APIs, microservices architecture, database optimization, and implementing secure authentication mechanisms.',
      skills: ['Node.js', 'Express.js', 'MongoDB', 'PostgreSQL', 'JWT', 'OAuth 2.0']
    },
    {
      title: 'Cloud & DevOps',
      description: 'Implementing CI/CD pipelines, containerization strategies, cloud infrastructure management, and automated deployment workflows for scalable applications.',
      skills: ['AWS', 'Docker', 'Kubernetes', 'GitHub Actions', 'Vercel', 'Heroku']
    },
    {
      title: 'AI & Machine Learning',
      description: 'Integrating artificial intelligence solutions, implementing machine learning algorithms, and developing intelligent systems for data-driven decision making.',
      skills: ['Python', 'TensorFlow', 'OpenAI API', 'Langchain', 'Pandas', 'Scikit-learn']
    },
    {
      title: 'IoT Development',
      description: 'Building Internet of Things solutions with sensor integration, real-time data processing, device communication protocols, and edge computing implementations.',
      skills: ['Arduino', 'Raspberry Pi', 'MQTT', 'WebSocket', 'Node-RED', 'Firebase IoT']
    },
    {
      title: 'Cybersecurity',
      description: 'Implementing security best practices, vulnerability assessment, penetration testing methodologies, secure coding practices, and threat analysis frameworks.',
      skills: ['OWASP', 'Burp Suite', 'Metasploit', 'Wireshark', 'Kali Linux', 'Security Headers']
    }
  ];

  return (
    <section id="skills" className="py-20 bg-secondary/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Technical Expertise & Specializations</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            A comprehensive overview of my technical skills and expertise across various domains of software development.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <Card 
              key={category.title} 
              className="glass-effect border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105 star-hover sparkle-on-hover group"
            >
              <CardHeader>
                <CardTitle className="text-xl text-gradient relative">
                  {category.title}
                  <span className="absolute -top-1 -right-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">⚡</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {category.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full border border-primary/20 hover:bg-primary/20 transition-colors floating-stars"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;