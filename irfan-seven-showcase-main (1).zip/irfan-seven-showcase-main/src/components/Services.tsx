import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Code, Smartphone, Cloud, Brain, Shield, Cpu } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Code,
      title: 'Web Development',
      description: 'Creating responsive and modern web applications using cutting-edge technologies.',
      technologies: ['React/Next.js', 'TypeScript', 'Tailwind CSS', 'Node.js'],
    },
    {
      icon: Smartphone,
      title: 'Mobile Development',
      description: 'Building cross-platform mobile applications for iOS and Android platforms.',
      technologies: ['React Native', 'Flutter', 'Swift', 'Kotlin'],
    },
    {
      icon: Cloud,
      title: 'Cloud Solutions',
      description: 'Implementing scalable cloud infrastructure and deployment strategies.',
      technologies: ['AWS', 'Docker', 'Kubernetes', 'CI/CD'],
    },
    {
      icon: Brain,
      title: 'AI Integration',
      description: 'Developing intelligent applications with machine learning capabilities.',
      technologies: ['Python', 'TensorFlow', 'OpenAI API', 'Langchain'],
    },
    {
      icon: Cpu,
      title: 'IoT Solutions',
      description: 'Creating connected device ecosystems and real-time data processing.',
      technologies: ['Arduino', 'Raspberry Pi', 'MQTT', 'WebSocket'],
    },
    {
      icon: Shield,
      title: 'Cybersecurity',
      description: 'Implementing security best practices and vulnerability assessments.',
      technologies: ['OWASP', 'Penetration Testing', 'Security Audits', 'Compliance'],
    },
  ];

  return (
    <section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Services</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            I offer a comprehensive range of development services to bring your ideas to life with modern technologies and best practices.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={service.title}
              className="glass-effect border-primary/20 hover:border-primary/40 transition-all duration-300 hover:scale-105 group star-hover sparkle-on-hover"
            >
              <CardHeader className="space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors relative floating-stars">
                  <service.icon className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-xl relative">
                  {service.title}
                  <span className="absolute -top-1 -right-6 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">✦</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {service.description}
                </p>
                
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-primary">Technologies:</h4>
                  <div className="flex flex-wrap gap-2">
                    {service.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-1 bg-secondary text-secondary-foreground text-xs rounded"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <Button variant="ghost" className="w-full mt-4">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;